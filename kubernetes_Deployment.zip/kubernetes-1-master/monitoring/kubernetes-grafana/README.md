- Create the configmap using the following command
``` kubectl create -f grafana-datasource-config.yaml ```

- Create the deployment
``` kubectl create -f deployment.yaml ```

- Create the service
``` kubectl create -f service.yaml ```

Chart Number to import - ``` 8588 ```
